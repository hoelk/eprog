/**
 * Created by hoelk on 06.05.15.
 */
public class MatrixIndexException extends Exception {
    MatrixIndexException(String message){
            super(message);
        }
    }
