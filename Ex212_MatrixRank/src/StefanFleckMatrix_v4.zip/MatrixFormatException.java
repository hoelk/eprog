/**
 * Created by hoelk on 06.05.15.
 */
public class MatrixFormatException extends Exception {
    MatrixFormatException(String message){
        super(message);
    }
}
